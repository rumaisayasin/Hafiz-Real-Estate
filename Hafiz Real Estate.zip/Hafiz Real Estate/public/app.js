// Handle contact form
document.getElementById("contactForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const formData = {
    name: e.target.name.value,
    email: e.target.email.value,
    message: e.target.message.value
  };

  const res = await fetch("/api/contact", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(formData)
  });

  const result = await res.json();
  document.getElementById("formResponse").innerText = result.success || result.error;
  e.target.reset();
});
